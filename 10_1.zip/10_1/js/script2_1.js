function kakunin2(btnNo){
  if (btnNo == 1){
    link = "Yahoo!Japan";
    href = "http://www.yahoo.co.jp/";
  }else{
    link = "Google";
    href = "http://www.google.co.jp/";
  }

  ret = confirm(link + "�֔�т܂��B�X�����ł����H");
  if (ret == true){
    location.href = href;
  }
}
function start(){
    location.href = "search_keyword.html";
}

function search_keyword(btnNo){
var sample_list = [
  {
    "list": "�]",
    "nestList": [
      {"nestContent": "�^���m�o"},
      {"nestContent": "�L��"},
      {"nestContent": "���o",
      "thirdlist": [
        {"thirdContent":"���o"},
        {"thirdContent":"VR/AR"},
        {"thirdContent":"�F�o"}
      ]
    }
    ]
  },
  {
    "list": "���X�gB",
    "content": "�R���e���cB",
    "nestList": [
      {"nestContent": "�q�v�f���X�gB1"},
      {"nestContent": "�q�v�f���X�gB2"},
      {"nestContent": "�q�v�f���X�gB3"}
    ]
  },
  {
    "list": "���X�gC",
    "content": "�R���e���cC",
    "nestList": [
      {"nestContent": "�q�v�f���X�gC1"},
      {"nestContent": "�q�v�f���X�gC2"}
    ]
  }
];
switch (btnNo) {
  case 1:
  if($('a1').text() == sample_list[0].list)
  {
    $('a1').text(sample_list[0].nestList[0].nestContent);
    $('a2').text(sample_list[0].nestList[1].nestContent);
    $('a3').text(sample_list[0].nestList[2].nestContent);
  }

    break;
    case 3:
    if($('a1').text() == sample_list[0].nestlist[2].nestContent)
    {
      $('a1').text(sample_list[0].nestList[0].thirdlist[0].thirdContent);
      $('a2').text(sample_list[0].nestList[1].thirdlist[1].thirdContent);
      $('a3').text(sample_list[0].nestList[2].thirdlist[2].thirdContent);
    }
    break;
  default:

}
}
/*
$('a1').text(sample_list[0].list);
$('a2').text(sample_list[1].list);
$('a3').text(sample_list[2].list);
$('a4').text(sample_list[0].nestList[2].thirdlist[2].thirdContent);
*/
