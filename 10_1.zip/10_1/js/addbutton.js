  var sample_list = [
    {
      "list": "�]",
      "nestList": [
        {"nestContent": "�^���m�o"},
        {"nestContent": "�L��"},
        {"nestContent": "���o",
        "thirdlist": [
          {"thirdContent":"���o"},
          {"thirdContent":"VR/AR"},
          {"thirdContent":"�F�o"}
        ]
      }
      ]
    },
    {
      "list": "���X�gB",
      "content": "�R���e���cB",
      "nestList": [
        {"nestContent": "�q�v�f���X�gB1"},
        {"nestContent": "�q�v�f���X�gB2"},
        {"nestContent": "�q�v�f���X�gB3"}
      ]
    },
    {
      "list": "���X�gC",
      "content": "�R���e���cC",
      "nestList": [
        {"nestContent": "�q�v�f���X�gC1"},
        {"nestContent": "�q�v�f���X�gC2"}
      ]
    }
  ];
  //�L�[���[�h�̗�
  function addbutton2()
  {

    var length = Object.keys(sample_list).length;
    console.log(length);
    var count = 0;
    var countcs = length-1;

    while(count < length){
      var key = sample_list[countcs].list;
      var html ='<a'+countcs+' href="#" class="square_btn" onClick="addbutton3('+countcs+')">'+key+'</a'+countcs+'><br />';
      var parent_object = document.getElementById("piyo");
      var button = document.createElement("button");
      parent_object.insertAdjacentHTML('afterbegin', html);
      $('a'+countcs).text(sample_list[countcs].list);
      count++;
      countcs--;

    }
}

function addbutton3(btnNo){
  var i = 0;
  while(i < 3){
  $('a'+i).remove();
  i++;
}
switch (btnNo) {
  case 0:
  var length = Object.keys(sample_list[btnNo].nestList).length;
  console.log(length);
  var count = 0;
  var countcs = length-1;

  while(count < length){
    var key = sample_list[0].nestList[countcs].nestContent;
    var html ='<a0'+countcs+' href="#" class="square_btn" onClick="addbutton4('+countcs+')">'+key+'</a0'+countcs+'><br />';
    var parent_object = document.getElementById("piyo");
    var button = document.createElement("button");
    parent_object.insertAdjacentHTML('afterbegin', html);
    $('a0'+countcs).text(sample_list[btnNo].nestList[countcs].nestContent);
    count++;
    countcs--;

  }

    break;
  default:

}
}

function addbutton4(btnNo){
  var i = 0;
  while(i < 3){
  $('a0'+i).remove();
  i++;
}
switch (btnNo) {
  case 2:
  var length = Object.keys(sample_list[0].nestList[btnNo].thirdlist).length;
  console.log(length);
  var count = 0;
  var countcs = length-1;

  while(count < length){
    var key = sample_list[0].nestList[2].thirdlist[countcs].thirdContent;
    var html ='<a02'+countcs+' href="#" class="square_btn" onClick="addbutton5('+countcs+')">'+key+'</a02'+countcs+'><br />';
    var parent_object = document.getElementById("piyo");
    var button = document.createElement("button");
    parent_object.insertAdjacentHTML('afterbegin', html);
    $('a02'+countcs).text(sample_list[0].nestList[btnNo].thirdlist[countcs].thirdContent);
    count++;
    countcs--;

  }

    break;
  default:

}
}
function addbutton5(btnNo){
switch (btnNo) {
  case 0:
  location.href = "answer.html";

    break;
  default:

}

}
