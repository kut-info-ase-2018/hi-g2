function kakunin(btnNo){
  if (btnNo == 1){
    link = "Yahoo!Japan";
    href = "http://www.yahoo.co.jp/";
  }else{
    link = "Google";
    href = "http://www.google.co.jp/";
  }

  ret = confirm(link + "�֔�т܂��B�X�����ł����H");
  if (ret == true){
    location.href = href;
  }
}
function start(){
    location.href = "search_keyword.html";
}
