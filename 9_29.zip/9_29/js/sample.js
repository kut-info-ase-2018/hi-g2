    $(function(){
      $.getJSON("../json/sample.json", function(sample_list){
        for(var i in sample_list){
          var h = '<dt>'
                + sample_list[i].list
                + '</dt>'
                + '<dd>'
                + sample_list[i].content
                + '</dd>';
          $("dl#wrap").append(h);
        }
      });
    });
